// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#ifndef _H_NONNON_WIN32_OLE_DEBUG
#define _H_NONNON_WIN32_OLE_DEBUG




#include "../../neutral/posix.c"


#include <ole2.h>




void
n_win_com_debug_cf2string( int cfFormat )
{

	n_posix_char str[ MAX_PATH ];


	GetClipboardFormatName( cfFormat, str, MAX_PATH );

	n_posix_debug_literal( "%d : %s", cfFormat, str );


	return;
}

void
n_win_com_debug_data( FORMATETC *pFormatetc, STGMEDIUM *pmedium )
{

	n_posix_debug_literal
	(
		"%04x %04x %04x %04x %04x : %04x %04x %04x",
		pFormatetc->cfFormat,
		pFormatetc->ptd,
		pFormatetc->dwAspect,
		pFormatetc->lindex,
		pFormatetc->tymed,
		pmedium->tymed,
		pmedium->hGlobal,
		pmedium->pUnkForRelease
	);


	return;
}


#endif // _H_NONNON_WIN32_OLE_DEBUG

