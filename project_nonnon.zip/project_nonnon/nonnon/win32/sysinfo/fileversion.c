// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lversion




#ifndef _H_NONNON_WIN32_SYSINFO_FILEVERSION
#define _H_NONNON_WIN32_SYSINFO_FILEVERSION




#include "../../neutral/memory.c"
#include "../../neutral/string.c"




#include <winver.h>

#ifdef _MSC_VER
#pragma comment( lib, "version" )
#endif // #ifdef _MSC_VER




#define n_sysinfo_fileversion_literal( n, q, r, l ) n_sysinfo_fileversion( n, n_posix_literal( q ), r, l )

bool
n_sysinfo_fileversion
(
	const n_posix_char *name,
	const n_posix_char *query,
	      n_posix_char *ret,
	      UINT          retlen
)
{

	// [Mechanism] : "query"
	//
	//	[Explorer]
	//
	//	FileDescription
	//	ProductName
	//	FileVersion
	//	ProductVersion
	//	LegalCopyright
	//	CompanyName
	//
	//	[Optional]
	//
	//	Comments
	//	InternalName
	//	LegalTrademarks
	//	PrivateBuild
	//	OriginalFilename
	//	SpecialBuild


	if ( ret == NULL ) { return true; }

	n_string_zero( ret, retlen );


	if ( query == NULL ) { return true; }


	bool b;


	u32 databyte = GetFileVersionInfoSize( name, NULL );
//n_posix_debug_literal( "%d", (int) databyte );
	if ( databyte == 0 ) { return true; }


	void *data = n_memory_new_closed( databyte );
	b = GetFileVersionInfo( name, 0, databyte, data );
	if ( b == false )
	{
//n_posix_debug_literal( " GetFileVersionInfo() " );

		n_memory_free_closed( data );

		return true;
	}


	// [!]
	//
	//	Neutral Language : "0000 04b0"
	//	almost files have only one entry
	//	system files have a localized entry

	typedef struct {

		WORD wLanguage;
		WORD wCodePage;

	} n_translate;

	n_translate *translate;
	UINT         translate_byte;
	UINT         translate_count;

	b = VerQueryValue
	(
		data,
		n_posix_literal( "\\VarFileInfo\\Translation" ),
		(void*) &translate,
		        &translate_byte
	);

	translate_count = translate_byte / sizeof( n_translate );

//n_posix_debug_literal( "%x %x %d", translate->wLanguage, translate->wCodePage, translate_byte );

	if ( ( b == false )||( translate_byte == 0 )||( translate_count == 0 ) )
	{
//n_posix_debug_literal( " VerQueryValue() #1 " );

		n_memory_free_closed( data );

		return true;
	}
//n_posix_debug_literal( " %d : %x(%d) ", translate_count, translate[ 0 ].wCodePage, translate[ 0 ].wCodePage );


	UINT index = 0;

	n_posix_char str[ 1024 ];

//VerLanguageName( translate[ index ].wLanguage, str, 1024 );
//n_posix_debug( str );

	n_posix_sprintf_literal
	(
		str,
		"\\StringFileInfo\\%04x%04x\\%s",
		translate[ index ].wLanguage,
		translate[ index ].wCodePage,
		query
	);
//n_posix_debug( str );


	n_posix_char **s;
	UINT           len;

	b = VerQueryValue( data, str, (void*) &s, &len );
	if ( b == false )
	{
//n_posix_debug_literal( " VerQueryValue() #2 " );

		n_memory_free_closed( data );

		return true;
	}


	n_string_copy_partial( (void*) s, ret, len );

	// [!] : some files have padding-like blank

	n_string_remove_blank( ret, ret );



	n_memory_free_closed( data );


	return false;
}


#endif // _H_NONNON_WIN32_SYSINFO_FILEVERSION


