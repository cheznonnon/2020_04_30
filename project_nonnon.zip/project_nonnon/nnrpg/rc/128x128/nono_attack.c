// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../../nonnon/project/define_unicode.c"




#include "../../../nonnon/neutral/bmp/all.c"




int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
 
	const s32 bmpsx = 64;
	const s32 bmpsy = 64;


	n_bmp bmp; n_bmp_zero( &bmp );

	u32 bg = n_bmp_white_invisible;
	n_bmp_new_fast( &bmp, bmpsx,bmpsy ); n_bmp_flush( &bmp, bg );


	n_bmp_circle( &bmp, 0,0     ,bmpsx,bmpsy / 4 * 3, bmpsx, n_bmp_white );
	n_bmp_circle( &bmp, 0,2     ,bmpsx,bmpsy / 4 * 3, bmpsx,          bg );

	n_bmp_circle( &bmp, 0,0 +  8,bmpsx,bmpsy / 4 * 3, bmpsx, n_bmp_white );
	n_bmp_circle( &bmp, 0,2 +  8,bmpsx,bmpsy / 4 * 3, bmpsx,          bg );

	n_bmp_circle( &bmp, 0,0 + 16,bmpsx,bmpsy / 4 * 3, bmpsx, n_bmp_white );
	n_bmp_circle( &bmp, 0,2 + 16,bmpsx,bmpsy / 4 * 3, bmpsx,          bg );


	n_bmp_save_literal( &bmp, "_result.bmp" );


	n_bmp_free( &bmp );


	return 0;
}

