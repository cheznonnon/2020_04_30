// hunyapiyo2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




LRESULT CALLBACK
n_hunyapiyo2_on_event( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{


	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == hunyapiyo2.timer_id_inactive )
		{
//n_oc_debug_count();

			if ( game.is_active == false )
			{
				n_game_loop();

				if ( n_game_refresh_is_on() )
				{
					n_game_on_paint();
				}
			}

		}

	break;


	} // switch



	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_hunyapiyo2_on_close( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_win_timer_exit( game.hwnd, hunyapiyo2.timer_id_inactive );


	return 0;
}

