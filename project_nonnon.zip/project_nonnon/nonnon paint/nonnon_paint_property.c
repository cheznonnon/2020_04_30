// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_paint_property_usedcolors( n_bmp *bmp )
{

	n_posix_char str[ 100 ];

	n_posix_sprintf_literal( str, "Used Colors : %ld", n_bmp_usedcolors_detect( bmp, 0 ) );

	n_paint_dialog_info( str );


	return;
}


