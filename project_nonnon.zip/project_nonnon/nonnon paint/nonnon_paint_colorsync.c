// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : valid only when EXE paths are the same




#define n_sync_init_literal( s ) n_sync_init( n_posix_literal( s ) )

UINT
n_sync_init( n_posix_char *name )
{
	return RegisterWindowMessage( name );
}

void
n_sync_go( UINT msg, WPARAM wparam, LPARAM lparam )
{

	// [x] : buggy : Win10 : hangup when you use n_win_message_send()

	n_win_message_post( HWND_BROADCAST, msg, wparam, lparam );


	return;
}

void
n_paint_sync_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_paint_sync_wm_synccolor = n_sync_init_literal( "NonnonPaint.ColorSynchronizer" );

	break;


	} // switch


	if ( msg == n_paint_sync_wm_synccolor )
	{

		int a = n_bmp_a( lparam );
		int r = n_bmp_r( lparam );
		int g = n_bmp_g( lparam );
		int b = n_bmp_b( lparam );

		nwclr_refresh( &cp, a,r,g,b );

		n_paint_colorhistory_add( lparam );

	}


	return;
}

