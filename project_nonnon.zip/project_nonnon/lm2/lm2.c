// LINE MASTER 2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/input.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"

#include "../nonnon/win32/gdi.c"

#include "../nonnon/neutral/wav/all.c"




// Constants

#define LM2_WAV_0            "N_PROJECT_SOUND_BWOPP"
#define LM2_WAV_2            "N_PROJECT_SOUND_CLICK"
#define LM2_WAV_3            "N_PROJECT_SOUND_WOOW"

#define N_LM2_BMP_ALL        ( 3 + 1 + 2 )
#define N_LM2_SND_ALL        ( 5 )

#define N_LM2_CHARA_INDEX    ( 0 )
#define N_LM2_MSG_1_INDEX    ( 1 )
#define N_LM2_MSG_2_INDEX    ( 2 )
#define N_LM2_BMPBG_INDEX    ( 3 )
#define N_LM2_DGT_1_INDEX    ( 4 )
#define N_LM2_DGT_2_INDEX    ( 5 )

#define N_LM2_BWOPP_INDEX    ( 0 )
#define N_LM2_SHOOT_INDEX    ( 1 )
#define N_LM2_CHIPP_INDEX    ( 2 )
#define N_LM2_WOOOW_INDEX    ( 3 )
#define N_LM2_PHOOT_INDEX    ( 4 )

#define N_LM2_CHARA_FIRE_MIN (    3 )
#define N_LM2_CHARA_FIRE_MAX (  255 )
#define N_LM2_CHARA_FIRE_RND ( 1500 )
#define N_LM2_VIRUS_FIRE_RND ( 2500 )
#define N_LM2_VIRUS_SX       (   18 )
#define N_LM2_VIRUS_SY       (    3 )
#define N_LM2_VIRUS_MAX      ( N_LM2_VIRUS_SX * N_LM2_VIRUS_SY )


#define N_LM2_FIRE_OFF       0
#define N_LM2_FIRE_ON        1
#define N_LM2_FIRE_ON_DOUBLE 2
#define N_LM2_FIRE_ON_FAST   2
#define N_LM2_FIRE_ON_TRICKY 3

#define N_LM2_VIRUS_STOP     0
#define N_LM2_VIRUS_FIRE     1
#define N_LM2_VIRUS_DEAD     2


#define N_LM2_POWER_NONE     ( 0 )
#define N_LM2_POWER_LASER    ( 1 )
#define N_LM2_POWER_GATLING  ( 2 )
#define N_LM2_POWER_STARDUST ( 3 )
#define N_LM2_POWER_SHIELD   ( 4 )

#define n_lm2_power_laser(    p ) ( ( (p)->level >=   5 )&&( (p)->power < N_LM2_POWER_LASER    ) )
#define n_lm2_power_gatling(  p ) ( ( (p)->level >=  25 )&&( (p)->power < N_LM2_POWER_GATLING  ) )
#define n_lm2_power_stardust( p ) ( ( (p)->level >=  50 )&&( (p)->power < N_LM2_POWER_STARDUST ) )
#define n_lm2_power_shield(   p ) ( ( (p)->level >= 100 )&&( (p)->power < N_LM2_POWER_SHIELD   ) )


typedef struct {

	s32          zoom;
	s32          csx,csy;
	s32          unit;
	s32          min_x, mid_x, max_x;
	s32          msg1_x, msg2_x;
	s32          hit_offset_x,hit_offset_y;

	s32          step_chara;
	s32          step_chara_fire;
	s32          step_virus_slow;
	s32          step_virus_fast;

	n_gdi        gdi;
	n_bmp        bmp[ N_LM2_BMP_ALL ];
	n_game_sound snd[ N_LM2_SND_ALL ];

	n_game_input input;

	n_game_chara item;
	n_game_chara chara;
	n_game_chara virus     [ N_LM2_VIRUS_MAX      ];
	n_game_chara chara_fire[ N_LM2_CHARA_FIRE_MAX ];
	n_game_chara virus_fire[ N_LM2_VIRUS_MAX      ];
	double       gatling   [ N_LM2_CHARA_FIRE_MAX ];

	int          chara_fire_min;
	int          chara_fire_max;
	int          chara_fire_rnd;
	int          chara_fire_cur;
	int          chara_fire_tmr;

	int          virus_sx;
	int          virus_sy;
	int          virus_max;
	int          virus_fire_rnd;
	int          virus_fire_tmr;

	bool         reset;
	u32          reset_timer;
	int          hiscore, score, score_counter;
	int          hiscore_prev, score_prev;
	int          level, power;

	bool         debug_invincible;

} n_lm2;


static n_lm2 lm2;




// Component

#include "./lm2_effect.c"




#define n_lm2_zero( p ) n_memory_zero( p, sizeof( n_lm2 ) )

#define n_lm2_vibrate_off( p ) n_lm2_vibrate( p, false )
#define n_lm2_vibrate_on(  p ) n_lm2_vibrate( p,  true )

void
n_lm2_vibrate( n_lm2 *p, bool is_on )
{

	int v;
	if ( is_on )
	{
		v = N_GAME_INPUT_XINPUT_VIBRATE_MAX;
	} else {
		v = 0;
	}

	n_game_input_XInput_vibrate( &p->input, v, v );


	return;
}

void
n_lm2_sound( n_lm2 *p, int index )
{

	n_game_sound *s = &p->snd[ index ];

	n_game_sound_loop( s );


	return;
}

void
n_lm2_gradient_refresh( n_lm2 *p, u32 upper, u32 lower )
{
//u32 tick = n_posix_tickcount();


	// [!] : 2 msec @ 1500MHz

	n_bmp_new_fast( &p->bmp[ N_LM2_BMPBG_INDEX ], p->csx, p->csy );

	if ( upper == lower )
	{
		n_bmp_flush( &p->bmp[ N_LM2_BMPBG_INDEX ], upper );
		return;
	}


	// [!] : Performance : CPU @ 1500MHz
	//
	//	1/1 : 200 msec
	//	1/2 :  70 msec
	//	1/3 :  50 msec

	int option = N_BMP_GRADIENT_RECTANGLE | N_BMP_GRADIENT_VERTICAL;

	s32 sy = p->csy / 3;
	n_bmp_gradient
	(
		&p->bmp[ N_LM2_BMPBG_INDEX ],
		0, p->csy - sy, p->csx, sy,
		upper, lower, option
	);


//n_game_hwndprintf_literal( "%d", (int) n_posix_tickcount() - tick );
	return;
}

void
n_lm2_digitbitmap( n_lm2 *p )
{

	// Hiscore

	if ( p->hiscore_prev != p->hiscore )
	{
//static int z = 0;n_game_hwndprintf_literal( "%d", z );z++;

		p->hiscore_prev = p->hiscore;

		n_posix_char str[ 10 ];

		p->gdi.sx   = 0;
		p->gdi.text = str;

		n_posix_sprintf_literal( str, "% 5d", p->hiscore );

		n_gdi_bmp( &p->gdi, &p->bmp[ N_LM2_DGT_1_INDEX ] );

	}

	{

		n_bmp *b  = &p->bmp[ N_LM2_MSG_1_INDEX ];
		s32    x  = p->msg1_x;
		s32    y  = 0;
		s32    sx = N_BMP_SX( b );
		s32    sy = N_BMP_SY( b );

		n_bmp_transcopy( b, &game.bmp, 0,0,sx,sy, x,y );

	}

	{

		n_bmp *b  = &p->bmp[ N_LM2_DGT_1_INDEX ];
		s32    x  = p->msg1_x + p->unit;
		s32    y  = 0;
		s32    sx = N_BMP_SX( b );
		s32    sy = N_BMP_SY( b );

		n_bmp_transcopy( b, &game.bmp, 0,0,sx,sy, x,y );

	}


	// Score

	if ( p->score_prev != p->score )
	{

		p->score_prev = p->score;

		n_posix_char str[ 10 ];

		p->gdi.sx   = 0;
		p->gdi.text = str;

		n_posix_sprintf_literal( str, "%d", p->score );

		n_gdi_bmp( &p->gdi, &p->bmp[ N_LM2_DGT_2_INDEX ] );

	}

	{

		n_bmp *b  = &p->bmp[ N_LM2_MSG_2_INDEX ];
		s32    x  = p->msg2_x - N_BMP_SX( &p->bmp[ N_LM2_DGT_2_INDEX ] );
		s32    y  = 0;
		s32    sx = N_BMP_SX( b );
		s32    sy = N_BMP_SY( b );

		n_bmp_transcopy( b, &game.bmp, 0,0,sx,sy, x,y );

	}

	{

		n_bmp *b  = &p->bmp[ N_LM2_DGT_2_INDEX ];
		s32    x  = p->msg2_x - N_BMP_SX( &p->bmp[ N_LM2_DGT_2_INDEX ] ) + p->unit;
		s32    y  = 0;
		s32    sx = N_BMP_SX( b );
		s32    sy = N_BMP_SY( b );

		n_bmp_transcopy( b, &game.bmp, 0,0,sx,sy, x,y );

	}


	return;
}

void
n_lm2_reset( n_lm2 *p )
{

	n_bmp *bmp_bg    = &p->bmp[ N_LM2_BMPBG_INDEX ];
	n_bmp *bmp_chara = &p->bmp[ N_LM2_CHARA_INDEX ];

	int    u         = p->unit;


	n_game_chara_zero( &p->chara );
	n_game_chara_zero( &p->item  );

	n_game_chara_bmp( &p->chara, &game.bmp, bmp_chara, bmp_bg, game.color );
	n_game_chara_bmp( &p->item,  &game.bmp, bmp_chara, bmp_bg, game.color );

	n_game_chara_src( &p->chara, u * 0,u * 0, u,u, 0,0 );
	n_game_chara_src( &p->item,  u * 0,u * 3, u,u, p->zoom * 3,p->zoom * 3 );

	n_game_chara_pos( &p->chara, p->mid_x, game.sy - p->unit );
	n_game_chara_pos( &p->item,  p->mid_x,         - p->unit );

	n_game_chara_prv( &p->chara );
	n_game_chara_prv( &p->item  );


	n_game_chara_bulk_zero( p->chara_fire, p->chara_fire_max );
	n_game_chara_bulk_zero( p->virus_fire, p->virus_max      );
	n_game_chara_bulk_zero( p->virus,      p->virus_max      );

	n_game_chara_bulk_bmp( p->chara_fire, p->chara_fire_max, &game.bmp, bmp_chara, bmp_bg, game.color );
	n_game_chara_bulk_bmp( p->virus     , p->virus_max,      &game.bmp, bmp_chara, bmp_bg, game.color );
	n_game_chara_bulk_bmp( p->virus_fire, p->virus_max,      &game.bmp, bmp_chara, bmp_bg, game.color );

	n_game_chara_bulk_src( p->chara_fire, p->chara_fire_max, u * 0,u * 2, u,u, p->zoom * 6,p->zoom * 2 );
	n_game_chara_bulk_src( p->virus     , p->virus_max,      u * 0,u * 1, u,u, p->zoom * 1,p->zoom * 1 );
	n_game_chara_bulk_src( p->virus_fire, p->virus_max,      u * 3,u * 1, u,u, p->zoom * 3,p->zoom * 3 );


	int i = 0;
	while( 1 )
	{

		int x = ( i % p->virus_sx ) * u;
		int y = ( i / p->virus_sx ) * u;

		n_game_chara_pos( &p->virus[ i ], u + x, u + y );
		n_game_chara_prv( &p->virus[ i ] );

		n_game_chara_pos( &p->virus_fire[ i ], -u, -u );
		n_game_chara_prv( &p->virus_fire[ i ] );


		i++;
		if ( i >= p->virus_max ) { break; }
	}


	p->hiscore_prev   = -1;
	p->score_prev     = -1;
	p->score          = 0;
	p->score_counter  = 0;
	p->level          = p->score / 100;
	p->power          = N_LM2_POWER_NONE;

	p->chara_fire_cur = p->chara_fire_min;
	p->chara_fire_tmr = p->chara_fire_rnd / p->chara_fire_cur;
	p->virus_fire_tmr = p->virus_fire_rnd / p->chara_fire_cur;


	n_lm2_effect_init( bmp_bg );


	return;
}

void
n_lm2_levelup( n_lm2 *p )
{

	p->chara_fire_cur = n_posix_min( p->chara_fire_max, p->chara_fire_cur + 1 );
	p->chara_fire_tmr = p->chara_fire_rnd / p->chara_fire_cur;
	p->virus_fire_tmr = p->virus_fire_rnd / p->chara_fire_cur;


	p->level      = p->score / 100;
	p->item.data  = false;
	p->item.data |= n_lm2_power_laser   ( p );
	p->item.data |= n_lm2_power_gatling ( p );
	p->item.data |= n_lm2_power_stardust( p );
	p->item.data |= n_lm2_power_shield  ( p );


	return;
}

void
n_lm2_input( n_lm2 *p )
{

	// Debug Center

	if ( n_win_is_input( VK_F1 ) )
	{
		p->score          = p->score + 100;
		p->score_counter  = p->score % 1000;
		p->chara_fire_cur = p->chara_fire_min + ( p->score / 100 );
		p->chara_fire_cur = n_posix_min( p->chara_fire_max, p->chara_fire_cur );
	}

	if ( n_win_is_input( VK_F2 ) )
	{
		p->item.data = true;
	}

	if ( n_win_is_input( VK_F3 ) )
	{
		p->debug_invincible = true;
	}


	// Player

	if ( n_game_input_loop( &p->input, VK_RIGHT ) )
	{
		p->chara.x = n_posix_min_s32( p->max_x, p->chara.x + p->step_chara );
	}

	if ( n_game_input_loop(& p->input, VK_LEFT ) )
	{
		p->chara.x = n_posix_max( p->min_x, p->chara.x - p->step_chara );
	}


//n_game_hwndprintf_literal( "%d", n_game_input_loop( &p->input, VK_SPACE ) );

	bool fire = false;


	static u32 single_timer = 0;
	static u32  rapid_timer = 0;
	static int  rapid       = 1;
	static int  rapid_step  = 4;

	if ( n_game_input_loop( &p->input, VK_SPACE ) )
	{

		if ( n_game_timer( &single_timer, p->chara_fire_tmr / rapid ) )
		{
			fire  = true;
			rapid = n_posix_max( 1, rapid - rapid_step );
		}

		rapid_timer = n_posix_tickcount() + 100;

	} else {

		if ( rapid_timer > n_posix_tickcount() )
		{
			rapid += rapid_step;
			rapid_timer = n_posix_tickcount();
		}

	}

	if ( fire )
	{

		int i = 0;
		while( 1 )
		{

			n_game_chara *cf = &p->chara_fire[ i ];

			if ( cf->data == N_LM2_FIRE_OFF )
			{

				n_lm2_sound( p, N_LM2_SHOOT_INDEX );

				cf->data = N_LM2_FIRE_ON;
				n_game_chara_pos( cf, p->chara.x, p->chara.y - p->unit );

				break; 
			}

			i++;
			if ( i >= N_LM2_CHARA_FIRE_MAX ) { break; }
		}

	}


	return;
}

void
n_lm2_init( n_lm2 *p )
{

	// Global

	n_bmp_safemode = false;


	// Size

	s32 desktop_sx; n_win_desktop_size( &desktop_sx, NULL );

	p->zoom            = n_posix_max_s32( 1, desktop_sx / 512 );

	{
		n_posix_char *cmdline = n_win_commandline_new();

		n_string_commandline_option_literal( "-lm2", cmdline );
		if ( false == n_string_is_empty( cmdline ) )
		{
			p->zoom = n_posix_max_s32( 1, n_posix_atoi( cmdline ) );
		}

		n_string_free( cmdline );
	}

	p->csx             = 320 * p->zoom;
	p->csy             = 240 * p->zoom;
	p->unit            =  16 * p->zoom;
	p->hit_offset_x    =   3 * p->zoom;
	p->hit_offset_y    =   6 * p->zoom;

	p->min_x           = 0;
	p->mid_x           = n_game_centering( p->csx, p->unit );
	p->max_x           = p->csx - p->unit;
	p->msg1_x          = p->unit;
	p->msg2_x          = p->csx - p->unit - p->unit;

	p->step_chara      = 3 * p->zoom;
	p->step_chara_fire = p->step_chara * 2;
	p->step_virus_slow = p->step_chara / 2;
	p->step_virus_fast = p->step_chara / 1;

	p->virus_sx        = N_LM2_VIRUS_SX;
	p->virus_sy        = N_LM2_VIRUS_SY;
	p->virus_max       = N_LM2_VIRUS_MAX;
	p->chara_fire_min  = N_LM2_CHARA_FIRE_MIN;
	p->chara_fire_max  = N_LM2_CHARA_FIRE_MAX;
	p->chara_fire_rnd  = N_LM2_CHARA_FIRE_RND;
	p->virus_fire_rnd  = N_LM2_VIRUS_FIRE_RND;


	// System

	n_game_title_literal( "LINE MASTER 2" );

	game.sx    = p->csx;
	game.sy    = p->csy;
	game.fps   = 30;
	game.lpf   = 1;
	game.color = n_bmp_black;

	n_game_dwm_onoff();

	n_game_window_fixed();

	if ( IsZoomed( game.hwnd ) ) { ShowWindow( game.hwnd, SW_RESTORE ); }


	n_game_input_zero( &p->input );
	n_game_input_init( &p->input, 0 );
	n_game_input_vk2udlr_default( &p->input );
	n_game_input_vk2button( &p->input, VK_SPACE, 0 );
	n_game_input_vk2button( &p->input, VK_SPACE, 1 );
	n_game_input_vk2button( &p->input, VK_SPACE, 2 );
	n_game_input_vk2button( &p->input, VK_SPACE, 3 );
	n_game_input_vk2button( &p->input, VK_SPACE, 4 );
	n_game_input_vk2button( &p->input, VK_SPACE, 5 );


	p->reset       = true;
	p->reset_timer = 0;


	// Resources

	n_memory_zero( p->bmp, sizeof( n_bmp ) * N_LM2_BMP_ALL );

	n_game_rc_load_bmp_literal( &p->bmp[ 0 ], "LM2_BMP_0" );
	n_game_rc_load_bmp_literal( &p->bmp[ 1 ], "LM2_BMP_1" );
	n_game_rc_load_bmp_literal( &p->bmp[ 2 ], "LM2_BMP_2" );

	n_bmp_scaler_big( &p->bmp[ 0 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 1 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 2 ], p->zoom );


	n_game_sound_bulk_zero( p->snd, N_LM2_SND_ALL );

	n_game_sound_init_literal( &p->snd[ 0 ], game.hwnd,  LM2_WAV_0  ); n_wav_smoother( &p->snd[ 0 ].wav );
	n_game_sound_init_literal( &p->snd[ 1 ], game.hwnd, "LM2_WAV_1" ); n_wav_smoother( &p->snd[ 1 ].wav );
	n_game_sound_init_literal( &p->snd[ 2 ], game.hwnd,  LM2_WAV_2  ); n_wav_smoother( &p->snd[ 2 ].wav );
	n_game_sound_init_literal( &p->snd[ 3 ], game.hwnd,  LM2_WAV_3  ); n_wav_smoother( &p->snd[ 3 ].wav );
	n_game_sound_init_literal( &p->snd[ 4 ], game.hwnd, "LM2_WAV_4" ); n_wav_smoother( &p->snd[ 4 ].wav );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sy                 = p->unit;
	gdi.sx                 = 0;
	gdi.style              = 0;//N_GDI_SMOOTH;

	gdi.base_color_bg      = game.color;
	gdi.base_color_fg      = 0;
	gdi.base_style         = N_GDI_BASE_SOLID;

	gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	gdi.icon               = n_posix_literal( "" );
	gdi.icon_index         = 0;
	gdi.icon_style         = N_GDI_ICON_DEFAULT;

	gdi.text               = NULL;
	gdi.text_font          = n_posix_literal( "Verdana" );
	gdi.text_size          = p->unit;
	gdi.text_color_main    = n_bmp_rgb( 255,255,255 );
	gdi.text_color_contour = n_bmp_rgb(   0,200,255 );
	gdi.text_style         = N_GDI_TEXT_CONTOUR;
	gdi.text_fxsize2       = 1;

	p->gdi = gdi;


	if ( game.dwm_onoff )
	{
		n_lm2_gradient_refresh( p, game.color, game.color );
	} else {
		n_lm2_gradient_refresh( p, game.color, n_bmp_rgb( 0,100,150 ) );
	}


	return;
}

void
n_lm2_loop( n_lm2 *p )
{

	// Control

	if ( ( p->reset )&&( n_game_timer( &p->reset_timer, 1000 ) ) )
	{

		p->reset = false;

		n_lm2_vibrate_off( p );

		n_lm2_reset( p );
		n_bmp_flush_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], &game.bmp );

		return;

	}


	// [Mechanism]
	//
	//	[Flow]
	//	Erase => Input => Draw
	//
	//	[Rendering Order]
	//	score => virus => virus_fire => effect => chara => chara_fire => item


	int i;


	// Erase : erase with previous position

	//n_bmp_box( &game.bmp, 0,0, p->csx,p->unit, game.color );
	n_bmp_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], &game.bmp, 0,0, p->csx,p->unit, 0,0 );


	n_game_chara_bulk_erase( p->virus     , p->virus_max );
	n_game_chara_bulk_erase( p->virus_fire, p->virus_max );


	n_lm2_effect_loop_erase();


	n_game_chara_erase( &p->chara );


	i = 0;
	while( 1 )
	{//break;

		n_game_chara *cf = &p->chara_fire[ i ];

		if ( cf->data != N_LM2_FIRE_OFF )
		{

			n_game_chara_erase( cf );

			cf->y -= p->step_chara_fire;
			if ( cf->y < -p->unit ) { cf->data = N_LM2_FIRE_OFF; }

			if ( cf->data == N_LM2_FIRE_ON_DOUBLE ) { cf->data = N_LM2_FIRE_OFF; }

			if ( p->power >= N_LM2_POWER_GATLING )
			{

				double o = sin( ( 2 * M_PI ) * p->gatling[ i ] );
				double a = p->unit;

				if ( p->power >= N_LM2_POWER_STARDUST ) { a *= 1 + n_game_random( 2 ); }

				cf->x = p->chara.x + ( a * o );

				p->gatling[ i ] += (double) 0.003 * p->level;

			}

		}

		i++;
		if ( i >= p->chara_fire_max ) { break; }
	}


	if ( p->item.data )
	{
		n_game_chara_erase( &p->item );
	}


	// Input

	if ( p->reset == false )
	{
		n_lm2_input( p );
	}


	// Draw

	i = 0;
	while( 1 )
	{//break;

		n_game_chara *c  = &p->chara;
		n_game_chara *v  = &p->virus     [ i ];
		n_game_chara *vf = &p->virus_fire[ i ];

		if ( v->data == N_LM2_VIRUS_STOP )
		{

			if ( 0 == n_game_random( p->virus_fire_tmr ) )
			{
				v->data = N_LM2_VIRUS_FIRE;
			}

			v->srcx = p->unit * 0;
			n_game_chara_draw( v );

		} else
		if ( v->data == N_LM2_VIRUS_FIRE )
		{

			if ( vf->data == N_LM2_FIRE_OFF )
			{
				vf->data = N_LM2_FIRE_ON + n_game_random( 3 );
				n_game_chara_pos( vf, v->x, v->y );
			} else
			if ( vf->data == N_LM2_FIRE_ON )
			{
				v ->srcx = p->unit * 1;
				vf->srcx = p->unit * 3;
				vf->mx   = p->zoom * 4;
				vf->my   = p->zoom * 4;
				vf->y += p->step_virus_slow;
			} else
			if ( vf->data == N_LM2_FIRE_ON_FAST )
			{
				v ->srcx = p->unit * 1;
				vf->srcx = p->unit * 3;
				vf->mx   = p->zoom * 4;
				vf->my   = p->zoom * 4;
				vf->y += p->step_virus_fast;
			} else
			if ( vf->data == N_LM2_FIRE_ON_TRICKY )
			{ 

				v->srcx = p->unit * 1;

				if ( vf->x > c->x )
				{
					vf->x -= p->step_virus_slow;
				} else {
					vf->x += p->step_virus_slow;
				}

				if ( i & 1 )
				{
					vf->y += p->step_virus_slow;
				} else {
					vf->y += p->step_virus_fast;
				}

				vf->srcx = ( p->unit * 3 ) - ( p->unit * ( vf->x & 1 ) );
				if ( vf->srcx == ( p->unit * 3 ) )
				{
					vf->mx   = p->zoom * 3;
					vf->my   = p->zoom * 3;
				} else {
					vf->mx   = p->zoom * 4;
					vf->my   = p->zoom * 4;
				}

			}


			if ( vf->y > p->csy )
			{

				v ->data = N_LM2_VIRUS_STOP;
				vf->data = N_LM2_FIRE_OFF;

			} else
			if (
				( p->debug_invincible == false )
				&&
				( vf->y >= c->y )
				&&
				( n_game_chara_is_hit_offset( vf, c, p->hit_offset_x,p->hit_offset_y, 0,0 ) )
				&&
				( p->reset == false )
			)
			{

				// GAME OVER

				if ( p->power >= N_LM2_POWER_SHIELD )
				{

					n_lm2_sound( p, N_LM2_PHOOT_INDEX );

				} else {

					p->reset = true;

					n_game_timer( &p->reset_timer, 0 );

					n_lm2_sound( p, N_LM2_BWOPP_INDEX );

					n_lm2_vibrate_on( p );

				}

				n_lm2_effect_go( c );

			}


			n_game_chara_draw( v  );
			n_game_chara_draw( vf );

		} else
		if ( 0 == n_game_random( p->virus_fire_tmr ) )
		{

			// Revive

			v->data = N_LM2_VIRUS_STOP;

		}


		int ii = 0;
		while( v->data != N_LM2_VIRUS_DEAD )
		{//break;

			n_game_chara *cf = NULL;
			while( 1 )
			{

				cf = &p->chara_fire[ ii ];
				ii++;

				if ( cf->data != N_LM2_FIRE_OFF ) { break; }
				if ( ii >= p->chara_fire_max ) { break; }
			}
			if ( ii >= p->chara_fire_max ) { break; }


			if ( n_game_chara_is_hit( cf, v ) )
			{

				n_lm2_sound( p, N_LM2_CHIPP_INDEX );

				n_lm2_effect_go( v );


				// Double Shot : one shot two viruses

				// [!] : laser is default behavior

				if ( p->power == N_LM2_POWER_NONE )
				{
					if ( cf->data == N_LM2_FIRE_ON )
					{
						cf->data = N_LM2_FIRE_ON_DOUBLE;
					} else {
						cf->data = N_LM2_FIRE_OFF;
					}
				}


				v ->data = N_LM2_VIRUS_DEAD;
				vf->data = N_LM2_FIRE_OFF;


				p->score++;
				if ( p->hiscore < p->score ) { p->hiscore = p->score; }

				p->score_counter++;
				if ( p->score_counter >= 100 )
				{
					p->score_counter = 0;
					n_lm2_levelup( p );
				}

			} else
			if (
				( p->power )
				&&
				( vf->data != N_LM2_FIRE_OFF )
				&&
				( n_game_chara_is_hit( cf, vf ) )
			)
			{

				// Virus Fire Eraser

				if ( p->power < N_LM2_POWER_GATLING ) { cf->data = N_LM2_FIRE_OFF; }
				v ->data = N_LM2_VIRUS_STOP;
				vf->data = N_LM2_FIRE_OFF;

			}

		}


		i++;
		if ( i >= p->virus_max ) { break; }
	}


	n_lm2_effect_loop_draw();


	if ( p->reset == false )
	{
		n_game_chara_draw( &p->chara );
	}


	i = 0;
	while( 1 )
	{

		n_game_chara *cf = &p->chara_fire[ i ];

		if ( cf->data != N_LM2_FIRE_OFF )
		{
			n_game_chara_draw( cf );
		}

		i++;
		if ( i >= p->chara_fire_max ) { break; }
	}

	if ( p->item.data )
	{

		p->item.y += p->step_virus_slow;

		if ( p->item.y > p->csy )
		{
			p->item.data = false;
			p->item.y    = -p->unit;
		}

		if ( n_game_chara_is_hit_offset( &p->item, &p->chara, p->hit_offset_x,p->hit_offset_y, 0,0 ) )
		{

			p->item.data = false;
			p->item.y    = -p->unit;

			n_game_chara_erase( &p->item  );
			n_game_chara_draw ( &p->chara );


			p->power++;
			p->item.srcx  = p->unit * n_posix_min( 3, p->power     );
			p->chara.srcx = p->unit * n_posix_min( 3, p->power - 1 );

			i = 0;
			while( 1 )
			{

				n_game_chara *cf = &p->chara_fire[ i ];

				cf->srcx = p->unit * n_posix_min( 3, p->power );

				if ( p->power == N_LM2_POWER_LASER )
				{
					cf->mx = p->zoom * 6;
					cf->my = p->zoom * 2;
				} else
				if ( p->power == N_LM2_POWER_GATLING )
				{
					cf->mx = p->zoom * 6;
					cf->my = p->zoom * 4;
				} else
				if ( p->power == N_LM2_POWER_STARDUST )
				{
					cf->mx = p->zoom * 3;
					cf->my = p->zoom * 3;
				}// else

				i++;
				if ( i >= p->chara_fire_max ) { break; }
			}


			n_lm2_sound( p, N_LM2_WOOOW_INDEX );

		} else {

			n_game_chara_draw( &p->item );

		}

	}


	// [!] : this position is important for hiscore

	n_lm2_digitbitmap( p );


	n_game_refresh_on();
	return;
}

void
n_lm2_exit( n_lm2 *p )
{

	int i = 0;
	while( 1 )
	{

		n_bmp_free( &p->bmp[ i ] );

		i++;
		if ( i >= N_LM2_BMP_ALL ) { break; }
	}

	i = 0;
	while( 1 )
	{

		n_game_sound_exit( &p->snd[ i ] );

		i++;
		if ( i >= N_LM2_SND_ALL ) { break; }
	}


	n_lm2_effect_exit();


	n_game_input_exit( &p->input );


	n_lm2_zero( p );


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_lm2_zero( &lm2 );
	n_lm2_init( &lm2 );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_lm2_exit( &lm2 );
		n_lm2_init( &lm2 );
		n_game_reset();
	}

	n_lm2_loop( &lm2 );


	return;
}

void
n_game_exit( void )
{

	n_lm2_exit( &lm2 );


	return;
}

#endif // #ifndef N_GAMECONSOLE

