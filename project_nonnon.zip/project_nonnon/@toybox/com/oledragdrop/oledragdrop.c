// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#define UNICODE

#define _WIN32_IE 0xffff


#include "../../../nonnon/win32/ole/_debug.c"
#include "../../../nonnon/win32/ole/IDropSource.c"
#include "../../../nonnon/win32/ole/IDropTarget.c"


#include "../../../nonnon/win32/win.c"


#include "../../../nonnon/project/macro.c"




// Patch for MinGW

#define CFSTR_LOGICALPERFORMEDDROPEFFECT TEXT("Logical Performed DropEffect")
#define CFSTR_TARGETCLSID TEXT("TargetCLSID")
#define CFSTR_UNTRUSTEDDRAGDROP TEXT("untrusteddragdrop")

// undocumented format

#define CFSTR_DRAGCONTEXT   TEXT("DragContext")
#define CFSTR_ISSHOWINGTEXT TEXT("IsShowingText")


const GUID n_guid_IID_IUnknown       = { 0x00000000,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
const GUID n_guid_IID_IStream        = { 0x0000000c,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };




void
n_oledragdrop_debug_clipformat( HWND hgui )
{

	n_win_hwndprintf_literal
	(

		hgui,

		"%04x CFSTR_FILECONTENTS       \r\n"
		"%04x CFSTR_FILEDESCRIPTOR     \r\n"
		"%04x CFSTR_FILENAME           \r\n"
		"%04x CFSTR_FILENAMEMAP        \r\n"
		"%04x CFSTR_SHELLIDLIST        \r\n"
		"%04x CFSTR_SHELLIDLISTOFFSET  \r\n"
		"---------- \r\n"
		"%04x CFSTR_NETRESOURCES \r\n"
		"%04x CFSTR_PRINTERGROUP \r\n"
		"%04x CFSTR_INETURL \r\n"
		"%04x CFSTR_SHELLURL \r\n"
		"---------- \r\n"
		"%04x CFSTR_INDRAGLOOP                  \r\n"
		"%04x CFSTR_LOGICALPERFORMEDDROPEFFECT  \r\n"
		"%04x CFSTR_PASTESUCCEEDED              \r\n"
		"%04x CFSTR_PERFORMEDDROPEFFECT         \r\n"
		"%04x CFSTR_PREFERREDDROPEFFECT         \r\n"
		"%04x CFSTR_TARGETCLSID                 \r\n"
		"%04x CFSTR_UNTRUSTEDDRAGDROP           \r\n"
		"---------- \r\n"
		"%04x CFSTR_DRAGCONTEXT \r\n"
		"%04x CFSTR_ISSHOWINGTEXT \r\n"

		"%s",

		RegisterClipboardFormat( CFSTR_FILECONTENTS ),
		RegisterClipboardFormat( CFSTR_FILEDESCRIPTOR ),
		RegisterClipboardFormat( CFSTR_FILENAME ),
		RegisterClipboardFormat( CFSTR_FILENAMEMAP ),
		RegisterClipboardFormat( CFSTR_SHELLIDLIST ),
		RegisterClipboardFormat( CFSTR_SHELLIDLISTOFFSET ),

		RegisterClipboardFormat( CFSTR_NETRESOURCES ),
		RegisterClipboardFormat( CFSTR_PRINTERGROUP ),
		RegisterClipboardFormat( CFSTR_INETURL ),
		RegisterClipboardFormat( CFSTR_SHELLURL ),

		RegisterClipboardFormat( CFSTR_INDRAGLOOP ),
		RegisterClipboardFormat( CFSTR_LOGICALPERFORMEDDROPEFFECT ),
		RegisterClipboardFormat( CFSTR_PASTESUCCEEDED ),
		RegisterClipboardFormat( CFSTR_PERFORMEDDROPEFFECT ),
		RegisterClipboardFormat( CFSTR_PREFERREDDROPEFFECT ),
		RegisterClipboardFormat( CFSTR_TARGETCLSID ),
		RegisterClipboardFormat( CFSTR_UNTRUSTEDDRAGDROP ),

		RegisterClipboardFormat( CFSTR_DRAGCONTEXT ),
		RegisterClipboardFormat( CFSTR_ISSHOWINGTEXT ),

		N_STRING_CRLF

	);


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :

		n_win_exedir2curdir();


		n_win_init_literal( hwnd, "", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 600,400, N_WIN_SET_CENTERING );


		n_win_gui_literal( hwnd, EDITOR, "", &hgui );
		n_win_move_simple( hgui, 0,0, 400,400, true );
		n_oledragdrop_debug_clipformat( hgui );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_RBUTTONUP :
	{

		IDataObject *pido = NULL;
		n_IDataObject_init( &pido, n_posix_literal( "neko.bmp" ) );

		OleSetClipboard( NULL );
		OleSetClipboard( pido );

		n_IDataObject_exit( &pido );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		OleSetClipboard( NULL );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

