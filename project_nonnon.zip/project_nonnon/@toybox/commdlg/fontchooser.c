

#include <stdio.h>
#include <stdlib.h>

#include <windows.h>
#include <commdlg.h>




int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	// Check
	//
	//	.lpLogFont : Needed : Win95 : program will crash


	CHOOSEFONT c;
	LOGFONT    lf;


	ZeroMemory( &c, sizeof(CHOOSEFONT) );

	c.lStructSize  = sizeof(CHOOSEFONT);
	c.Flags        = CF_BOTH;
	c.lpLogFont    = &lf;

	ChooseFont( &c );


	return 0;
}

